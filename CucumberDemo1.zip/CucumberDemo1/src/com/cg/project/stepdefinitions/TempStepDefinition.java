package com.cg.project.stepdefinitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TempStepDefinition
{
	@Given("^User is on the login page of www\\.github\\.com$")
	public void user_is_on_the_login_page_of_www_github_com() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enters valid username and invalid password$")
	public void user_enters_valid_username_and_invalid_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Error to be displayed as \"(.*?)\"$")
	public void error_to_be_displayed_as(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enters invalid username and valid password$")
	public void user_enters_invalid_username_and_valid_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enters valid username and valid password$")
	public void user_enters_valid_username_and_valid_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^User is directed to the success page$")
	public void user_is_directed_to_the_success_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
}
